const express = require("express");
const cors = require("cors");
const axios = require("axios");
const path = require("path");

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static("public")); // Serve frontend files

const API_TOKEN = "r8_AVDDuHw9Nl5LWm1yDNdEEkQ1jDziOMr2yHlIv"; // Replace with real API key

// ✅ Serve frontend
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// ✅ Generate image request
app.post("/generate-image", async (req, res) => {
  try {
    // Replace (subject) with "nstr"
    req.body.input.prompt = req.body.input.prompt.replace(
      /\(subject\)/g,
      "male nstr"
    );

    const response = await axios.post(
      "https://api.replicate.com/v1/predictions",
      req.body,
      {
        headers: {
          Authorization: `Bearer ${API_TOKEN}`,
          "Content-Type": "application/json",
          Prefer: "wait",
        },
      }
    );

    res.json(response.data);
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ error: "Failed to fetch data from Replicate" });
  }
});

// ✅ Get image generation status
app.get("/generate-image-status/:id", async (req, res) => {
  const predictionId = req.params.id;
  try {
    const response = await axios.get(
      `https://api.replicate.com/v1/predictions/${predictionId}`,
      {
        headers: {
          Authorization: `Bearer ${API_TOKEN}`,
        },
      }
    );

    res.json(response.data);
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ error: "Failed to get prediction status" });
  }
});

app.listen(5000, () =>
  console.log("✅ Server running on http://localhost:5000")
);
